import { FluxStore } from "..";
import { ActivityFlags } from "../../enums";

export type SpotifyDeviceType = "computer" | "smartphone" | "speaker" | "tv" | "game_console" | "automobile" | "unknown";
export type SpotifyMediaType = "track" | "episode";
export type SpotifyAlbumType = "album" | "single" | "compilation";

export interface SpotifyDevice {
    id: string;
    is_active: boolean;
    is_private_session: boolean;
    is_restricted: boolean;
    name: string;
    supports_volume: boolean;
    type: SpotifyDeviceType;
    volume_percent: number;
}

export interface SpotifySocket {
    accessToken: string;
    accountId: string;
    connectionId: string;
    isPremium: boolean;
    socket: WebSocket;
}

export interface SpotifySocketAndDevice {
    socket: SpotifySocket;
    device: SpotifyDevice;
}

export interface SpotifyArtist {
    id: string;
    name: string;
    external_urls: { spotify: string; };
}

export interface SpotifyImage {
    url: string;
    height: number;
    width: number;
}

export interface SpotifyAlbum {
    id: string;
    name: string;
    type: SpotifyAlbumType;
    image: SpotifyImage | null;
}

export interface SpotifyTrack {
    id: string;
    name: string;
    duration: number;
    isLocal: boolean;
    type: SpotifyMediaType;
    album: SpotifyAlbum;
    artists: SpotifyArtist[];
}

export interface SpotifyPlayerState {
    track: SpotifyTrack;
    startTime: number;
    context: { uri: string; } | null;
}

export interface SpotifyActivity {
    name: string;
    assets: {
        large_image?: string;
        large_text?: string;
    };
    details: string;
    state: string | undefined;
    timestamps: {
        start: number;
        end: number;
    };
    party: {
        id: string;
    };
    sync_id?: string;
    flags?: ActivityFlags;
    metadata?: {
        context_uri: string | undefined;
        album_id: string;
        artist_ids: string[];
        type: SpotifyMediaType;
        button_urls: string[];
    };
}

export interface SpotifySyncingWith {
    oderId: string;
    partyId: string;
    sessionId: string;
    userId: string;
}

export class SpotifyStore extends FluxStore {
    hasConnectedAccount(): boolean;
    getActiveSocketAndDevice(): SpotifySocketAndDevice | null;
    getPlayableComputerDevices(): SpotifySocketAndDevice[];
    canPlay(deviceId: string): boolean;
    getSyncingWith(): SpotifySyncingWith | undefined;
    wasAutoPaused(): boolean;
    getLastPlayedTrackId(): string | undefined;
    getTrack(): SpotifyTrack | null;
    getPlayerState(accountId: string): SpotifyPlayerState | null;
    shouldShowActivity(): boolean;
    getActivity(): SpotifyActivity | null;
}
