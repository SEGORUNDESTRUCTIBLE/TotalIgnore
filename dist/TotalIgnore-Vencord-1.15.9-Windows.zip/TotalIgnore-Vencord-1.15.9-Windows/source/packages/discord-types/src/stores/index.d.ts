// please keep in alphabetical order
export * from "./AccessibilityStore";
export * from "./ActiveJoinedThreadsStore";
export * from "./ApplicationCommandIndexStore";
export * from "./ApplicationStore";
export * from "./ApplicationStreamingStore";
export * from "./ApplicationStreamPreviewStore";
export * from "./AuthenticationStore";
export * from "./AuthorizedAppsStore";
export * from "./CallStore";
export * from "./ChannelMemberStore";
export * from "./ChannelRTCStore";
export * from "./ChannelSectionStore";
export * from "./ChannelStore";
export * from "./ClientThemesBackgroundStore";
export * from "./CollapsedVoiceChannelStore";
export * from "./ConnectedAccountsStore";
export * from "./DraftStore";
export * from "./EditMessageStore";
export * from "./EmojiStore";
export * from "./ExperimentStore";
export * from "./FluxStore";
export * from "./FriendsStore";
export * from "./GIFPickerViewStore";
export * from "./GuildChannelStore";
export * from "./GuildMemberCountStore";
export * from "./GuildMemberStore";
export * from "./GuildReadStateStore";
export * from "./GuildRoleStore";
export * from "./GuildScheduledEventStore";
export * from "./GuildStore";
export * from "./InstantInviteStore";
export * from "./InviteStore";
export * from "./JoinedThreadsStore";
export * from "./LocaleStore";
export * from "./MediaEngineStore";
export * from "./MessageRequestStore";
export * from "./MessageStore";
export * from "./NotificationSettingsStore";
export * from "./OverridePremiumTypeStore";
export * from "./PendingReplyStore";
export * from "./PermissionStore";
export * from "./PopoutWindowStore";
export * from "./PresenceStore";
export * from "./PrivateChannelSortStore";
export * from "./ReadStateStore";
export * from "./ReferencedMessageStore";
export * from "./RelationshipStore";
export * from "./RTCConnectionStore";
export * from "./RunningGameStore";
export * from "./SafetyHubStore";
export * from "./SelectedChannelStore";
export * from "./SelectedGuildStore";
export * from "./SelfPresenceStore";
export * from "./SessionsStore";
export * from "./SortedGuildStore";
export * from "./SoundboardStore";
export * from "./SpellCheckStore";
export * from "./SpotifyStore";
export * from "./StickersStore";
export * from "./StreamerModeStore";
export * from "./ThemeStore";
export * from "./ThreadMemberListStore";
export * from "./TypingStore";
export * from "./UploadAttachmentStore";
export * from "./UserAffinitiesStore";
export * from "./UserGuildJoinRequestStore";
export * from "./UserGuildSettingsStore";
export * from "./UserProfileSettingsStore";
export * from "./UserProfileStore";
export * from "./UserSettingsProtoStore";
export * from "./UserStore";
export * from "./VoiceStateStore";
export * from "./WindowStore";

/**
 * React hook that returns stateful data for one or more stores
 * You might need a custom comparator (4th argument) if your store data is an object
 * @param stores The stores to listen to
 * @param mapper A function that returns the data you need
 * @param dependencies An array of reactive values which the hook depends on. Use this if your mapper or equality function depends on the value of another hook
 * @param isEqual A custom comparator for the data returned by mapper
 *
 * @example const user = useStateFromStores([UserStore], () => UserStore.getCurrentUser(), null, (old, current) => old.id === current.id);
 */
export type useStateFromStores = <T>(
    stores: any[],
    mapper: () => T,
    dependencies?: any,
    isEqual?: (old: T, newer: T) => boolean
) => T;
