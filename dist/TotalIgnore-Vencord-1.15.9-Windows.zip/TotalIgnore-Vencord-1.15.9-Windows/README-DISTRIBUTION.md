# TotalIgnore by Dr. Avinash Mandre — Vencord Windows bundle

Created and published by **Dr. Avinash Mandre**.

This is an independently built Windows desktop bundle based on Vencord 1.15.9,
with the TotalIgnore plugin included. It is a community-built client
modification, not an official Discord or Vencord installer. The source
snapshot and applicable license notices are included in this archive.

## Install

1. Extract the ZIP to a folder.
2. Completely close Discord.
3. Double-click **Install-TotalIgnore.bat** and confirm that Discord is closed.
4. Start Discord. Open **User Settings → Vencord → Plugins**, enable
   **TotalIgnore**, and use **Ignore user** from a person's context menu or add
   their ID in the plugin settings.

The launcher installs this bundle into Discord Stable for the current Windows
user. It does not need administrator privileges. Vencord stores settings in the
current Windows user's Vencord data directory (normally
`%APPDATA%\Vencord`); settings and ignored-user IDs are not included in this
archive.

Ignored voice members, call tiles, and their screen-share tiles are hidden from
the local UI. Local mute is stored through Discord's voice settings so it also
applies to new connections; unignoring restores the user's previous local mute
state.

For Discord PTB or Canary, edit the launcher and replace `stable` with `ptb`
or `canary`. The installer discovers that Discord installation from the
selected branch.

To remove Vencord, close Discord and double-click
**Uninstall-TotalIgnore.bat**. This removes Vencord from Discord Stable.

## Important

- This build is intended for Windows desktop Discord. It may stop working
  after Discord changes its UI or client internals.
- TotalIgnore is local, best-effort filtering. Discord still sends voice and
  presence data to the client; this does not make a user invisible to Discord
  or other participants.
- The archive does not include anyone's Discord account settings, ignored-user
  IDs, tokens, or local client data. Each recipient configures their own list.
- The bundle is distributed under the repository's GPL-3.0-or-later license.
  Preserve the included `LICENSE` and generated legal notices when
  redistributing it.
